package org.newtglobal;

public class HelloClass {
	public String demo() {
		return "Hello World" ;
		
	}

}
