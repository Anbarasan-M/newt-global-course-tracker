package org.studyeasy;

public class Main {

    public static void main(String[] args) {
        String[] names = {"Pooja", "Raj", "Moris", "Deana"};


        for (String name:
             names) {
            System.out.println(name);
        }


    }
}