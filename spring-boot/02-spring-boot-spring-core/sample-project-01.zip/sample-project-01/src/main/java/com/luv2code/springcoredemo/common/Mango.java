package com.luv2code.springcoredemo.common;

import org.springframework.stereotype.Component;

@Component
public class Mango implements Fruit{
    @Override
    public String getTaste() {
        return "Mango is sour";
    }

    public Mango(){
        System.out.println("In Constructor: " + getClass().getSimpleName());
    }
}
