package com.luv2code.springcoredemo.common;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;

@Component
public class Apple implements Fruit {

    @Override
    public String getTaste() {
        return "Taste of apple is sweet";
    }

    @PostConstruct
    public void postConstruct(){
        System.out.println("This is in postConstruct");
    }

    @PreDestroy
    public void preDestroy(){
        System.out.println("This is in preDestroy");
    }


    public Apple(){
        System.out.println("In Constructor: " + getClass().getSimpleName());
    }
}
