package com.luv2code.springcoredemo.common;

public interface Fruit {

    String getTaste();
}
