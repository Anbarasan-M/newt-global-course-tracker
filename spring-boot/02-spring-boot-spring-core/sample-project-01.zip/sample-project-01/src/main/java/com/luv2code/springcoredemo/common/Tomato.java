package com.luv2code.springcoredemo.common;

import org.springframework.stereotype.Component;

@Component
public class Tomato implements Fruit{
    @Override
    public String getTaste() {
        return "Tomato is juicy";
    }

    public Tomato(){
        System.out.println("In Constructor: " + getClass().getSimpleName());
    }
}
