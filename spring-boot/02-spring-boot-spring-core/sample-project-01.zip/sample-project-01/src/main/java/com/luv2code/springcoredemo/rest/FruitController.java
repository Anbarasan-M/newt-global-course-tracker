package com.luv2code.springcoredemo.rest;

import com.luv2code.springcoredemo.common.Fruit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FruitController {

    Fruit fruit;

    @Autowired
    FruitController(@Qualifier("apple") Fruit theFruit){
        fruit = theFruit;
        System.out.println("In Constructor: " + getClass().getSimpleName());
    }
    @GetMapping("/endpoint")
    public String fruitTaste(){
        return fruit.getTaste();
    }
}
