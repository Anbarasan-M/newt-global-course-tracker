package com.luv2code.springcoredemo.common;

import org.springframework.stereotype.Component;

@Component
public class Banana implements Fruit{
    @Override
    public String getTaste() {
        return "Banana is creamy";
    }

    public Banana(){
        System.out.println("In constructor " + getClass().getSimpleName());
    }
}
